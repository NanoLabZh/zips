<html>
<body>
<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<form action="./data.php" method="post" enctype="multipart/form-data">
<?php
	// $con = mysql_connect("localhost","dreambab_tudou","wangchao2008");
	// if (!$con) {
	// 	die('连不上数据库哦亲:' . mysql_error());
	// }
	// mysql_select_db("dreambab_tudou", $con);

	// $result = mysql_query("select * from ver_tab");

	// while($row = mysql_fetch_array($result))
	// {
	// 	echo  "查询成功"
	// 	echo "<br />";
	// }
?>

<br />
<br />
<font color=red>请输入请版本信息</font>
<br />
<br />
客户端版本号: <input type="text" name="clientVer"><br>
<br />
<br />
资源版本号: <input type="text" name="resVer"><br>
<br />
<br />
apk更新URL: <input type="text" style="width:400px;height:20px" name="apkurl"><br>
<br />
<br />
apk更新URL2: <input type="text" style="width:400px;height:20px" name="apkurl2"><br>
<br />
<br />
ios更新URL: <input type="text" style="width:400px;height:20px" name="iosurl"><br>
<br />
<br />
ios更新URL2: <input type="text" style="width:400px;height:20px" name="iosurl2"><br>
<br />
<br />
res更新URL: <input type="text" style="width:400px;height:20px" name="resurl"><br>
<br />
<br />
res更新URL2: <input type="text" style="width:400px;height:20px" name="resurl2"><br>
<br />
<br />
<label for="file">选择zip包:</label>
<input type="file" name="file" id="file" /> 
<br />
<br />
<br />
<input type="submit" style="width:80px;height:60px" name="submit" value="提交" />
</form>

</body>
</html>